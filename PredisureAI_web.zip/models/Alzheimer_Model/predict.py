import pandas as pd
import joblib
import numpy as np
import os


def load_model_and_assets(model_dir='models'):
    model_path = os.path.join(model_dir, 'model_xgb.pkl')
    scaler_path = os.path.join(model_dir, 'standard_scaler.pkl')
    feature_names_path = os.path.join(model_dir, 'feature_names.pkl')
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        feature_names = joblib.load(feature_names_path)
        print("Model, scaler ve özellik isimleri başarıyla yüklendi.")
        return model, scaler, feature_names
    except FileNotFoundError as e:
        print(f"Hata: Gerekli model veya ön işleme dosyaları bulunamadı: {e}")
        print(
            "Lütfen ilgili projenizin 'main.py' dosyasını çalıştırarak bu dosyaların 'models/' klasöründe oluşturulduğundan emin olun.")
        return None, None, None


def predict_risk(new_data):
    model, scaler, feature_names = load_model_and_assets()
    if model is None or scaler is None or feature_names is None:
        return "Prediction failed due to missing model files. Please train the model first by running main.py."
    new_df = pd.DataFrame([new_data], columns=feature_names)
    for col in new_df.select_dtypes(include='object').columns:
        new_df[col] = new_df[col].astype(str)
    for col in new_df.columns:
        if new_df[col].dtype == 'object':
            new_df[col] = pd.factorize(new_df[col])[0]
    new_df = new_df.reindex(columns=feature_names, fill_value=0)
    numeric_cols = [col for col in new_df.columns if new_df[col].dtype in ['int64', 'float64'] and col != 'Class']
    new_df[numeric_cols] = scaler.transform(new_df[numeric_cols])
    prediction = model.predict(new_df)
    if prediction[0] == 1:
        return "Based on the provided data, the model predicts a higher risk of Alzheimer's disease."
    else:
        return "Based on the provided data, the model predicts a lower risk of Alzheimer's disease."


if __name__ == '__main__':
    example_new_data = {
        'PatientID': 1000,
        'Age': 75,
        'Gender': 'Male',
        'Ethnicity': 'White',
        'EducationLevel': 12,
        'BMI': 28.5,
        'Smoking': 'No',
        'AlcoholConsumption': 'Moderate',
        'PhysicalActivity': 'High',
        'DietQuality': 'High',
        'SleepQuality': 'High',
        'FamilyHistoryAlzheimers': 'Yes',
        'CardiovascularDisease': 'No',
        'Diabetes': 'No',
        'Depression': 'Yes',
        'HeadInjury': 'No',
        'Hypertension': 'Yes',
        'SystolicBP': 140,
        'DiastolicBP': 90,
        'CholesterolTotal': 220,
        'CholesterolLDL': 140,
        'CholesterolHDL': 50,
        'CholesterolTriglycerides': 130,
        'MMSE': 26,
        'FunctionalAssessment': 'Mild impairment',
        'MemoryComplaints': 'Yes',
        'BehavioralProblems': 'No',
        'ADL': 'Independent',
        'Confusion': 'No',
        'Disorientation': 'No',
        'PersonalityChanges': 'No',
        'DifficultyCompletingTasks': 'Yes',
        'Forgetfulness': 'Yes',
        'Diagnosis': -0.7397000929442957,
        'DoctorInCharge': 0.0
    }

    if 'Diagnosis' in example_new_data:
        del example_new_data['Diagnosis']
    if 'DoctorInCharge' in example_new_data:
        del example_new_data['DoctorInCharge']

    result = predict_risk(example_new_data)
    print(result)
