import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from xgboost import XGBClassifier
import joblib
import os

def load_and_merge_datasets(file_paths, merge_on='PatientID'):
    if not file_paths:
        raise ValueError("Lütfen en az bir dosya yolu sağlayın.")
    main_df = None
    for i, file_path in enumerate(file_paths):
        try:
            current_df = pd.read_csv(file_path)
            print(f"'{file_path}' başarıyla yüklendi.")
            if i == 0:
                main_df = current_df
            else:
                if merge_on not in main_df.columns or merge_on not in current_df.columns:
                    print(f"Uyarı: Birleştirme anahtarı '{merge_on}' en az bir dosyada eksik. Bu dosya için birleştirme atlanıyor.")
                    continue
                main_df = pd.merge(main_df, current_df, on=merge_on, how='outer')
                print(f"'{file_path}' başarıyla birleştirildi.")
        except FileNotFoundError:
            print(f"Hata: '{file_path}' bulunamadı. Lütfen dosya yolunu kontrol edin.")
            if main_df is None:
                return pd.DataFrame()
            continue
    if main_df is None:
        raise ValueError("Hiçbir veri dosyası yüklenemedi veya birleştirilemedi.")
    print("Mevcut tüm veri setleri birleştirildi.")
    return main_df

def preprocess_data(df):
    df.drop(columns=['ID', 'Unnamed: 0'], errors='ignore', inplace=True)
    target_column_name = 'Diagnosis'
    if target_column_name != 'Class' and target_column_name in df.columns:
        df.rename(columns={target_column_name: 'Class'}, inplace=True)
        print(f"'{target_column_name}' sütunu bulundu ve 'Class' olarak yeniden adlandırıldı.")
    elif 'Class' not in df.columns:
        raise KeyError(f"Ne '{target_column_name}' ne de 'Class' sütunu veri setinde bulunamadı. Lütfen dosyanızı kontrol edin ve hedef sütun adını güncelleyin.")
    df['Class'] = pd.to_numeric(df['Class'], errors='coerce')
    df.dropna(subset=['Class'], inplace=True)
    if df.empty:
        raise ValueError("Ön işleme sonrası DataFrame boş. Hedef sütunda geçerli veri bulunamadı.")
    unique_class_values = sorted(df['Class'].unique())
    if len(unique_class_values) == 2:
        class_map = {unique_class_values[0]: 0, unique_class_values[1]: 1}
        df['Class'] = df['Class'].map(class_map).astype(int)
        print(f"Hedef sütun 'Class' tamsayılara dönüştürüldü: {unique_class_values[0]} -> 0 ve {unique_class_values[1]} -> 1.")
    else:
        print(f"Uyarı: 'Class' sütununda beklenen 2 yerine {len(unique_class_values)} benzersiz değer bulundu: {unique_class_values}. Değerler en yakın tamsayıya yuvarlanacak.")
        df['Class'] = df['Class'].round().astype(int)
    categorical_cols = df.select_dtypes(include='object').columns.tolist()
    if 'Class' in categorical_cols:
        categorical_cols.remove('Class')
    for col in categorical_cols:
        df[col] = LabelEncoder().fit_transform(df[col].astype(str))
    df.fillna(df.median(numeric_only=True), inplace=True)
    numeric_cols = [col for col in df.select_dtypes(include=['int64', 'float64']).columns if col != 'Class']
    scaler = StandardScaler()
    if not df[numeric_cols].empty:
        df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    models_dir = 'models'
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    joblib.dump(scaler, os.path.join(models_dir, 'standard_scaler.pkl'))
    return df

def train_model(df):
    X = df.drop('Class', axis=1)
    y = df['Class']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    model.fit(X_train, y_train)
    models_dir = 'models'
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    joblib.dump(model, os.path.join(models_dir, 'model_xgb.pkl'))
    joblib.dump(X_train.columns.tolist(), os.path.join(models_dir, 'feature_names.pkl'))
    print("XGBoost modeli başarıyla eğitildi ve 'models/model_xgb.pkl' olarak kaydedildi.")
    print("Özellik isimleri 'models/feature_names.pkl' olarak kaydedildi.")
    return model, X_test, y_test

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    report = classification_report(y_test, y_pred)
    matrix = confusion_matrix(y_test, y_pred)
    outputs_dir = 'outputs'
    if not os.path.exists(outputs_dir):
        os.makedirs(outputs_dir)
    with open(os.path.join(outputs_dir, 'classification_report.txt'), 'w') as f:
        f.write("Classification Report:\n")
        f.write(report)
        f.write("\nConfusion Matrix:\n")
        f.write(str(matrix))
    print("\nDeğerlendirme Raporu:")
    print(report)
    print("Karmaşıklık Matrisi:")
    print(matrix)

def main():
    print("Veri setleri yükleniyor ve birleştiriliyor...")
    data_files = [
        'data/cleaned_alzheimers_data.csv',
    ]
    df = load_and_merge_datasets(data_files, merge_on='PatientID')
    if df.empty:
        print("Veri yükleme veya birleştirme hatası nedeniyle pipeline durduruldu.")
        return
    print("Veri setleri başarıyla birleştirildi.")
    print("\nVeri ön işleme başlatılıyor...")
    df = preprocess_data(df)
    print("Veri ön işleme tamamlandı.")
    print("\nModel eğitimi başlatılıyor...")
    model, X_test, y_test = train_model(df)
    print("Model eğitimi tamamlandı.")
    print("\nModel değerlendirme başlatılıyor...")
    evaluate_model(model, X_test, y_test)
    print("Model değerlendirme tamamlandı.")

if __name__ == '__main__':
    main()
