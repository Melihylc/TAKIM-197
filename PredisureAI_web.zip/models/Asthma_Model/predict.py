import pandas as pd
import joblib
import os


def load_model_and_assets(model_dir='models'):
    try:
        model_path = os.path.join(model_dir, 'asthma_model.pkl')
        scaler_path = os.path.join(model_dir, 'asthma_scaler.pkl')
        label_encoder_path = os.path.join(model_dir, 'asthma_label_encoder.pkl')
        feature_names_path = os.path.join(model_dir, 'asthma_feature_names.pkl')

        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        label_encoder = joblib.load(label_encoder_path)
        feature_names = joblib.load(feature_names_path)

        return model, scaler, label_encoder, feature_names
    except FileNotFoundError as e:
        print(f"Hata: Gerekli model veya ön işleme dosyaları bulunamadı: {e}")
        print(
            "Lütfen ilgili projenizin 'main.py' dosyasını çalıştırarak bu dosyaların 'models/' klasöründe oluşturulduğundan emin olun.")
        return None, None, None, None


def predict_asthma_risk(new_data):
    model, scaler, label_encoder, feature_names = load_model_and_assets()
    if model is None or scaler is None or label_encoder is None or feature_names is None:
        return "Tahmin, eksik model dosyaları nedeniyle başarısız oldu. Lütfen önce 'main.py' dosyasını çalıştırarak modeli eğitin."

    new_df = pd.DataFrame([new_data])

    for col in new_df.columns:
        if new_df[col].dtype == 'object':
            new_df[col] = label_encoder.transform(new_df[col])

    new_df = new_df.reindex(columns=feature_names, fill_value=0)

    numeric_cols = [col for col in new_df.columns if new_df[col].dtype in ['int64', 'float64']]
    if numeric_cols:
        new_df[numeric_cols] = scaler.transform(new_df[numeric_cols])

    prediction = model.predict(new_df)
    predicted_class = label_encoder.inverse_transform(prediction)

    return f"Sağlanan verilere göre, tahmin edilen astım riski kategorisi: {predicted_class[0]}"


if __name__ == '__main__':
    example_new_data = {
        'Age': 45,
        'Gender': 'Female',
        'Genetic_Predisposition': 'No',
        'Family_History': 'Yes',
        'Obesity': 'Yes',
        'Smoking': 'No',
        'Chronic_Conditions': 'No',
        'Environmental_Factors': 'Dust Mites',
        'Wheezing': 'Yes',
        'Shortness_of_Breath': 'Yes'
    }

    result = predict_asthma_risk(example_new_data)
    print(result)
