import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
from xgboost import XGBClassifier
import joblib
import os

def preprocess_data(file_path):
    df = pd.read_csv(file_path)
    df.drop(columns=['ID'], errors='ignore', inplace=True)
    if 'NObeyesdad' in df.columns:
        df.rename(columns={'NObeyesdad': 'Class'}, inplace=True)
    else:
        raise KeyError("'NObeyesdad' sütunu veri setinde bulunamadı. Lütfen dosyanızı kontrol edin.")
    label_encoder = LabelEncoder()
    df['Class'] = label_encoder.fit_transform(df['Class'])
    categorical_cols = df.select_dtypes(include='object').columns.tolist()
    for col in categorical_cols:
        df[col] = label_encoder.fit_transform(df[col])
    df.fillna(df.median(numeric_only=True), inplace=True)
    numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns.drop('Class', errors='ignore')
    scaler = StandardScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    models_dir = 'models'
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    joblib.dump(scaler, os.path.join(models_dir, 'obesity_scaler.pkl'))
    joblib.dump(label_encoder, os.path.join(models_dir, 'obesity_label_encoder.pkl'))
    return df

def train_model(df):
    X = df.drop('Class', axis=1)
    y = df['Class']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss')
    model.fit(X_train, y_train)
    models_dir = 'models'
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    joblib.dump(model, os.path.join(models_dir, 'obesity_model_xgb.pkl'))
    joblib.dump(X_train.columns.tolist(), os.path.join(models_dir, 'obesity_feature_names.pkl'))
    return model, X_test, y_test

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    report = classification_report(y_test, y_pred)
    matrix = confusion_matrix(y_test, y_pred)
    outputs_dir = 'outputs'
    if not os.path.exists(outputs_dir):
        os.makedirs(outputs_dir)
    with open(os.path.join(outputs_dir, 'obesity_classification_report.txt'), 'w') as f:
        f.write("Classification Report:\n")
        f.write(report)
        f.write("\nConfusion Matrix:\n")
        f.write(str(matrix))
    print("\nDeğerlendirme Raporu:")
    print(report)
    print("Karmaşıklık Matrisi:")
    print(matrix)

def main():
    print("Veri ön işleme başlatılıyor...")
    df = preprocess_data('data/obesity_data.csv')
    print("Veri ön işleme tamamlandı.")
    print("\nModel eğitimi başlatılıyor...")
    model, X_test, y_test = train_model(df)
    print("Model eğitimi tamamlandı.")
    print("\nModel değerlendirme başlatılıyor...")
    evaluate_model(model, X_test, y_test)
    print("Model değerlendirme tamamlandı.")

if __name__ == '__main__':
    main()
