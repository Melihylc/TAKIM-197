
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler

def preprocess_data(file_path):
    df = pd.read_csv(file_path)
    df.drop(columns=['ID', 'Unnamed: 0'], errors='ignore', inplace=True)
    categorical_cols = df.select_dtypes(include='object').columns.drop('Class', errors='ignore')
    for col in categorical_cols:
        df[col] = LabelEncoder().fit_transform(df[col].astype(str))
    df.fillna(df.median(numeric_only=True), inplace=True)
    numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns.drop('Class', errors='ignore')
    scaler = StandardScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    if 'Class' in df.columns:
        df['Class'] = df['Class'].map({'Nondemented': 0, 'Demented': 1, 'Converted': 1, 'Possible': 1})
    return df
