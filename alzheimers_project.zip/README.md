
# 🧠 Alzheimer Hastalığı Tahmin Modeli

Bu proje, Alzheimer hastalığını sınıflandırmak için bir makine öğrenmesi modeli geliştirmektedir. Modelde XGBoost algoritması kullanılmıştır.

## 📁 Proje Yapısı

- `src/`: Kodlar
- `data/`: Ham ve temizlenmiş veri
- `models/`: Kaydedilen model
- `outputs/`: Tahmin sonuçları
- `main.py`: Tüm pipeline'ı çalıştırır

## 🚀 Kurulum

```bash
pip install -r requirements.txt
python main.py
```

## 🛠 Kullanılanlar

- Python
- XGBoost
- Scikit-learn
- Pandas
